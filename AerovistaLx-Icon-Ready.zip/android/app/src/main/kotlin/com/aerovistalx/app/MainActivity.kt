package com.aerovistalx.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
