import 'package:flutter/material.dart';
import 'firebase_service.dart';
import 'package:webview_flutter/webview_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseService.initializeIfConfigured();
  runApp(const AerovistaLxApp());
}

class AerovistaLxApp extends StatelessWidget {
  const AerovistaLxApp({super.key});
  @override
  Widget build(BuildContext context) => const MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AerovistaLx',
    home: AerovistaLxHome(),
  );
}

class AerovistaLxHome extends StatefulWidget {
  const AerovistaLxHome({super.key});
  @override
  State<AerovistaLxHome> createState() => _AerovistaLxHomeState();
}

class _AerovistaLxHomeState extends State<AerovistaLxHome> {
  late final WebViewController controller;
  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF080B14))
      ..setNavigationDelegate(NavigationDelegate())
      ..loadFlutterAsset('assets/index.html');
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF080B14),
    body: SafeArea(child: WebViewWidget(controller: controller)),
  );
}
