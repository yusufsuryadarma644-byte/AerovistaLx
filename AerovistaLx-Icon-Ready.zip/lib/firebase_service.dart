import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

/// Firebase foundation for AerovistaLx.
///
/// Add the real Firebase values as --dart-define entries when building.
/// If the values are absent, the app continues to run without initializing
/// Firebase, so a clean checkout can still build before Firebase is configured.
class FirebaseService {
  FirebaseService._();

  static bool get isReady => Firebase.apps.isNotEmpty;

  static Future<bool> initializeIfConfigured() async {
    const apiKey = String.fromEnvironment('FIREBASE_API_KEY');
    const appId = String.fromEnvironment('FIREBASE_APP_ID');
    const senderId = String.fromEnvironment('FIREBASE_MESSAGING_SENDER_ID');
    const projectId = String.fromEnvironment('FIREBASE_PROJECT_ID');
    const authDomain = String.fromEnvironment('FIREBASE_AUTH_DOMAIN');
    const storageBucket = String.fromEnvironment('FIREBASE_STORAGE_BUCKET');

    if (apiKey.isEmpty ||
        appId.isEmpty ||
        senderId.isEmpty ||
        projectId.isEmpty) {
      return false;
    }

    try {
      await Firebase.initializeApp(
        options: FirebaseOptions(
          apiKey: apiKey,
          appId: appId,
          messagingSenderId: senderId,
          projectId: projectId,
          authDomain: authDomain.isEmpty ? null : authDomain,
          storageBucket: storageBucket.isEmpty ? null : storageBucket,
        ),
      );
      return true;
    } catch (error) {
      // Keep the app usable if Firebase is not configured correctly yet.
      // Details are available in the debug console for troubleshooting.
      // ignore: avoid_print
      print('Firebase initialization failed: $error');
      return false;
    }
  }

  static FirebaseAuth get auth {
    _requireFirebase();
    return FirebaseAuth.instance;
  }

  static FirebaseFirestore get firestore {
    _requireFirebase();
    return FirebaseFirestore.instance;
  }

  static void _requireFirebase() {
    if (!isReady) {
      throw StateError(
        'Firebase is not configured. Follow FIREBASE_SETUP.md first.',
      );
    }
  }
}
