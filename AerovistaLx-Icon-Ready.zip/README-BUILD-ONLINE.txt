AEROVISTALX — RELEASE APK TANPA BACKEND API

ZIP ini berisi source project Flutter AerovistaLx dan workflow GitHub Actions untuk membuat APK release secara online. Tidak memerlukan VPS dan tidak menggunakan API_BASE_URL/backend API.

CARA BUILD:
1. Ekstrak ZIP di HP atau komputer.
2. Buat repository baru di GitHub (misalnya project-aerovistalx).
3. Upload ISI folder project ke root repository, bukan ZIP sebagai satu file. Pastikan file .github/workflows/release-apk.yml ikut ter-upload.
4. Buka tab Actions di repository. Jika diminta, aktifkan Actions.
5. Pilih workflow “Build AerovistaLx Release APK”, lalu tekan Run workflow. Bisa juga otomatis berjalan saat push ke branch main/master.
6. Jika selesai dengan status hijau, buka run tersebut dan unduh artifact “AerovistaLx-base-apk”. Di dalamnya ada AerovistaLx.apk.

CATATAN:
- APK tidak dibuat di perangkat ini; GitHub Actions yang membangunnya setelah workflow dijalankan.
- Firebase tetap opsional. Tanpa Firebase secrets, aplikasi akan dibangun tetapi Firebase tidak diinisialisasi. Untuk memakai Firebase, ikuti FIREBASE_SETUP.md dan tambahkan secrets yang diperlukan di Settings > Secrets and variables > Actions.
- Tidak perlu API_BASE_URL, VPS, Termius, atau server backend untuk build APK ini.
- APK release ini menggunakan konfigurasi signing default Flutter/Android untuk build release. Untuk distribusi publik/Play Store, siapkan signing keystore sendiri dengan aman.
